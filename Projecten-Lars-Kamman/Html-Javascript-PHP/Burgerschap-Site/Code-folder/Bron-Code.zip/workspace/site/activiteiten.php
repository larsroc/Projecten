<!DOCTYPE html>
<html>
    <head>
       <link rel="stylesheet" type="text/scss" href="css/home.scss">
       <?php include 'menu.php';?>
    </head>
    <body>
          <div align="center">     
<iframe src="https://calendar.google.com/calendar/embed?showTitle=0&amp;showCalendars=0&amp;height=600&amp;wkst=1&amp;bgcolor=%23FFFFFF&amp;src=kammanlars1%40gmail.com&amp;color=%231B887A&amp;src=nl.dutch%23holiday%40group.v.calendar.google.com&amp;color=%23125A12&amp;ctz=Europe%2FAmsterdam" style="border-width:0" width="800" height="600" frameborder="0" scrolling="no"></iframe>
          </div>
    </body>
    <footer>
        <?php include 'footer.php';?>
    </footer>
</html>