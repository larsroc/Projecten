<?php
session_start();

require "database.php";

?>
<style>
.footer {
    position: fixed;
    left: 0;
    bottom: 0;
    width: 100%;
    background-color: #212e44;
    color: white;
    text-align: center;
}
</style>

<div class="footer">
Copyright &copy; Lars Kamman
</div>