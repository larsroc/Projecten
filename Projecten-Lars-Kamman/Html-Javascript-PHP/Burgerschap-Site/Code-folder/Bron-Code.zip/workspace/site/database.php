<?php
$servername = "localhost";
$username = "bigbrother84";
$password = "";
$conn = new PDO("mysql:host=$servername;dbname=user", $username, $password)
?>